#!/bin/bash

# Check if /storage/tal/ directory exists
if [ -d "/storage/tal/" ]; then
    # Create symbolic links for SSH, VSCode, Cursor extensions, and Git config

    # Ensure the .ssh directory exists
    mkdir -p /root/.ssh
    # Remove existing link or directory and create a new symbolic link for SSH
    rm -rf /root/.ssh/*
    ln -s /storage/tal/ssh/* /root/.ssh/

    # Ensure the .vscode-server/extensions directory exists
    mkdir -p /root/.vscode-server/extensions
    # Remove existing link or directory and create a new symbolic link for VSCode extensions
    rm -rf /root/.vscode-server/extensions
    ln -s /storage/tal/vscode/extensions /root/.vscode-server/extensions

    # Ensure the .cursor-server/extensions directory exists
    mkdir -p /root/.cursor-server/extensions
    # Remove existing link or directory and create a new symbolic link for Cursor extensions
    rm -rf /root/.cursor-server/extensions
    ln -s /storage/tal/vscode/extensions /root/.cursor-server/extensions

    # Remove existing link or file and create a new symbolic link for Git config
    rm -f /root/.gitconfig
    ln -s /storage/tal/git_config/.gitconfig /root/.gitconfig
fi

# Start the SSH server
exec /usr/sbin/sshd -D

# add to enrty point to move to the storage directory
cd /storage/tal/git/
