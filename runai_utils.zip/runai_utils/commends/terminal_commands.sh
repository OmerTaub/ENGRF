## Runai Tel Aviv CLI commands

# access to strorage
kube_bash_storage

## My Custom Commands
# run dev job with my dev image 
runai submit --name=tal-dev --large-shm --pvc=storage:/storage --add-capability AUDIT_WRITE --add-capability SYS_CHROOT -g 0.5 -i talgrossman/runai-dev --node-pool bengal
runai submit --name=tal-dev --large-shm --pvc=storage:/storage --add-capability AUDIT_WRITE --add-capability SYS_CHROOT -g 1.0 -i talgrossman/runai-dev --node-pool blaufer
runai submit --name=tal-dev-sam2-env --large-shm --pvc=storage:/storage --add-capability AUDIT_WRITE --add-capability SYS_CHROOT --gpu-memory 20G -i talgrossman/runai-dev-sam2-env



# port forward to dev job
runai port-forward tal-dev --port 2222:22
# remove sshkegen if job restarted
ssh-keygen -f "/home/tal/.ssh/known_hosts" -R "[localhost]:2222"

# ssh from a terminal
ssh -X -p 2222 root@localhost


# mount storage using sshfs
sshfs -p 2222 root@127.0.0.1:/storage ~/runai_storage/
# or 
sshfs -p 2222 root@localhost:/storage ~/runai_storage/

## vscdoe
# symlink the vscode server extension directory to the storage
ln -s /storage/tal/vscode/extensions /root/.vscode-server/
# to sync newly installed extensions to the storage - be careful with because we have symlink to the storage
rsync -av --progress --delete ~/.vscode-server/extensions/ /storage/tal/vscode/extensions/

## cursor
# from remote: symlink the cursor server extension directory to the storage
mkdir -p /root/.cursor-server && ln -s /storage/tal/cursor-server/* /root/.cursor-server/
# to sync newly installed extensions to the storage
rsync -av --progress --delete ~/.cursor-server/ /storage/tal/cursor-server/

## git
# sync git ssh  sorage (from remote) to .ssh
rsync -av --progress /storage/tal/ssh/ ~/.ssh/
# instead of sync ln -s
ln -s /storage/tal/ssh /root/.ssh
# sync git config (from remote)
rsync -av --progress /storage/tal/git_config/.gitconfig ~/.

# sync git remote to local 
rsync -avR --progress "/home/tal/runai_storage/tal/git/sam2_eval/./SemiSam2" "/home/tal/git/sam2_eval/"
# sync git local to remote 
rsync -avR --progress --dry-run "/home/tal/git/sam2_eval/./SemiSam2" "/home/tal/runai_storage/tal/git/sam2_eval/"

## sync results (locally using the mounted sroage)
rsync -avR --progress --dry-run "/home/tal/runai_storage/tal/git/sam2_eval/./results/SemiSAM2/SemiSam2_amos/results_to_save_for_now/" /home/tal/git/sam2_eval/
# Key points:
# -a preserves permissions, timestamps, etc
# -v verbose output
# -R or --relative maintains directory structure
# The /. in the middle of the source path tells rsync where to start the relative path
# The trailing slash on source directory copies contents of the directory
# This will recreate the path structure starting from results in your destination directory.

## run job with python script
runai submit \
  --name=train-ldseg-liver-full-ct-b32-e2500 \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 16G \
  -i talgrossman/runai-dev-sam2-env \
  --command -- bash -c "cd /storage/tal/git/LDSeg/LDSeg_pytorch && \
    /opt/venv/bin/python /storage/tal/git/LDSeg/LDSeg_pytorch/LDSeg_pytorch_npz.py \
      --config config_presets/liver_full_training_ct.yaml \
      --run-name liver-full-ct-b32-e2500"
runai submit \
  --name=train-ldseg-liver-full-mri-b32-e2500 \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 16G \
  -i talgrossman/runai-dev-sam2-env \
  --command -- bash -c "cd /storage/tal/git/LDSeg/LDSeg_pytorch && \
    /opt/venv/bin/python /storage/tal/git/LDSeg/LDSeg_pytorch/LDSeg_pytorch_npz.py \
      --config config_presets/liver_full_training_mri.yaml \
      --run-name liver-full-mri-b32-e2500"
    
runai submit \
  --name=train-all-classes-mt-without-sam2-20000iter-64128128-rotations \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 8G \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/sam2_eval && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/sam2_eval/SemiSam2/train_amos_with_sam_multi_class.py \
    --root_path ./data/amos22/from_guidednet/2022_amos \
    --exp train-all-classes-mt-without-sam2-with_randomrotfliptrans-crop64128128-20000iter-18-labeled-guidednetpreprocesseddata \
    --results_path ./results/SemiSAM2 \
    --patch_size 64 128 128 \
    --max_iterations 20000 \
    --class_label 0 \
    --model unet_3D \
    --data_num 180 \
    --labeled_num 18 \
    --batch_size 2 \
    --labeled_bs 1"

runai submit \
  --name=train-mt-sam2-tiny512-float32-samitint5-p4-30000iter-64128128 \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 8G \
  --node-pool faculty \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/sam2_eval && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/sam2_eval/SemiSam2/train_amos_with_sam_multi_class.py \
    --root_path ./data/amos22/from_guidednet/2022_amos \
    --exp train-mt-sam2-tiny512-float32-saminterval5-p4-30000iter-64128128 \
    --results_path ./results/SemiSAM2 \
    --patch_size 64 128 128 \
    --max_iterations 30000 \
    --class_label 0 \
    --model unet_3D \
    --data_num 180 \
    --labeled_num 18 \
    --batch_size 2 \
    --labeled_bs 1 \
    --use_sam2 \
    --sam2_img_size 512 \
    --use_float32 \
    --sam2_model_path ./checkpoints/sam2.1_hiera_tiny.pt \
    --sam2_propagation_mode unidirectional \
    --sam2_iteration_interval 5 \
    --prompt_freq 4"

# flare
runai submit \
  --name=train-all-classes-mt-without-sam2-20000iter-64128128-flare \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 8G \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/sam2_eval && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/sam2_eval/SemiSam2/train_amos_with_sam_multi_class.py \
    --root_path ./data/FLARE22/from_guidednet/2022_flare \
    --exp train-all-classes-mt-without-sam2-no_randomrotfliptrans-crop64128128-20000iter-42-labeled-guidednetpreprocesseddata \
    --results_path ./results/SemiSAM2 \
    --patch_size 64 128 128 \
    --max_iterations 20000 \
    --class_label 0 \
    --model unet_3D \
    --data_num 84 \
    --labeled_num 42 \
    --batch_size 2 \
    --labeled_bs 1"

runai submit \
  --name=train-mt-sam2-tiny512-float32-samitint5-p4-64128128-flare \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --backoff-limit=0 \
  --gpu-memory 8G \
  --node-pool faculty \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/sam2_eval && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/sam2_eval/SemiSam2/train_amos_with_sam_multi_class.py \
    --root_path ./data/FLARE22/from_guidednet/2022_flare \
    --exp train-mt-sam2-tiny512-float32-saminterval5-p4-30000iter-64128128-flare \
    --results_path ./results/SemiSAM2 \
    --patch_size 64 128 128 \
    --max_iterations 30000 \
    --class_label 0 \
    --model unet_3D \
    --data_num 84 \
    --labeled_num 42 \
    --batch_size 2 \
    --labeled_bs 1 \
    --use_sam2 \
    --sam2_img_size 512 \
    --use_float32 \
    --sam2_model_path ./checkpoints/sam2.1_hiera_tiny.pt \
    --sam2_propagation_mode unidirectional \
    --sam2_iteration_interval 5 \
    --prompt_freq 4"
    
# run SemiSam1 with no sam
runai submit \
  --name=run-semisam1-mt-no-sam \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  -g 0.5 \
  --node-pool faculty \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/SemiSAM && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/SemiSAM/code_semisam+/train_MT_3D.py \
    --exp BraTS/MT_labeld_2_outof_250"

 # UDA - source trainer   
runai submit \
  --name=run-source-trainer-lk \
  --large-shm \
  --pvc=storage:/storage \
  --add-capability AUDIT_WRITE \
  --add-capability SYS_CHROOT \
  --gpu-memory 8G \
  -i talgrossman/runai-dev \
  --command -- bash -c "cd /storage/tal/git/DFG/ && \
    source /storage/tal/venvs/sam2_env/bin/activate && \
    python /storage/tal/git/DFG/main_trainer_source.py \
    --config_file /storage/tal/git/DFG/configs/train_source_seg_tal_src_is_ct_only_lk.yaml"

# bengal 0.2 == 16gb
# bengal 0.3 == 24gb
# bengal 0.4 == 32gb
# bengal 0.5 == 40gb
# bengal 0.6 == 48gb
# bengal 0.7 == 56gb
# bengal 0.8 == 64gb
# bengal 0.9 == 72gb
# bengal 1.0 == 80gb

# faculty 1.0 == 24gb
# faculty 0.9 == 21.6gb
# faculty 0.8 == 19.2gb
# faculty 0.7 == 16.8gb
# faculty 0.6 == 14.4gb
# faculty 0.5 == 12gb
# faculty 0.4 == 9.6gb
# faculty 0.3 == 7.2gb
# faculty 0.2 == 4.8gb
# faculty 0.1 == 2.4gb

# blaufer 0.14 = 7gb
# balufer 1.0 = 50gb
# balufer 0.9 = 45gb
# balufer 0.8 = 40gb
# balufer 0.7 = 35gb
# balufer 0.6 = 30gb
# balufer 0.5 = 25gb
# balufer 0.4 = 20gb
# balufer 0.3 = 15gb
# balufer 0.2 = 10gb