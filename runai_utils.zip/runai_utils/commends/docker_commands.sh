cd project_root

docker build --pull --rm -f 'docker_files/Dockerfile_runai_dev' -t 'talgrossman/runai-dev' .

docker push talgrossman/runai-dev:latest

# #### sam2_env image 
# Build SAM2 environment image
docker build --pull --rm -f 'docker_files/Dockerfile_runai_dev_sam2_env' -t 'talgrossman/runai-dev-sam2-env' .

docker push talgrossman/runai-dev-sam2-env:latest

